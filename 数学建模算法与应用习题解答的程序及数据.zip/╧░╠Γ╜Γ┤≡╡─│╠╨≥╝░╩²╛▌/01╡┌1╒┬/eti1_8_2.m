load data
fid=fopen('data1_1.txt','w');
fprintf(fid,'%8.4f\n',A');
fclose(fid);
