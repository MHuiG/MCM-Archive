load data
xlswrite('book1_1.xls',A);
