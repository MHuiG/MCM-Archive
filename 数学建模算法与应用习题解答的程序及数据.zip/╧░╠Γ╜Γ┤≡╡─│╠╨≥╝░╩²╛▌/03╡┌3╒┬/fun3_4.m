function y=fun3_4(x);
c1=[2 3 1];
c2=[3 1 0];
y=c1*x+c2*x.^2;
y=-y;
